import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { X } from 'lucide-react';
import { useStore } from '@/store/useStore';
import TopNavigationBar from '@/components/TopNavigationBar';
import Toast from '@/components/Toast';

export default function SettingsPage() {
  const { settings, showToast } = useStore();
  const [formSettings, setFormSettings] = useState({ ...settings });
  const [hasChanges, setHasChanges] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    setHasChanges(JSON.stringify(formSettings) !== JSON.stringify(settings));
  }, [formSettings, settings]);

  const handleSave = async () => {
    setIsSaving(true);
    await new Promise((r) => setTimeout(r, 600));
    setIsSaving(false);
    setSaved(true);
    showToast('Settings saved');
    setTimeout(() => setSaved(false), 3000);
    setHasChanges(false);
  };

  const removeCourse = (i: number) => {
    setFormSettings((s) => ({ ...s, courses: s.courses.filter((_, idx) => idx !== i) }));
  };

  const removeBranch = (i: number) => {
    setFormSettings((s) => ({ ...s, branches: s.branches.filter((_, idx) => idx !== i) }));
  };

  return (
    <div className="min-h-screen bg-cc-base-deep pt-14">
      <TopNavigationBar />
      <Toast />

      <div className="max-w-[640px] mx-auto px-4 lg:px-6 py-10">
        <motion.h1
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="font-mono text-[clamp(1.75rem,3vw,2.25rem)] font-light leading-tight tracking-[-0.02em] text-cc-text-high mb-8"
        >
          SETTINGS
        </motion.h1>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
          className="bg-cc-base-surface border border-cc-gridline rounded p-6 shadow-inset-glow"
        >
          {/* BGV Configuration */}
          <div className="mb-8">
            <h3 className="section-header mb-3">BGV CONFIGURATION</h3>
            <div>
              <label className="font-mono text-[10px] font-medium uppercase tracking-[0.06em] text-cc-text-mid block mb-1.5">
                BGV Team Email
              </label>
              <input
                type="email"
                value={formSettings.bgvTeamEmail}
                onChange={(e) => setFormSettings((s) => ({ ...s, bgvTeamEmail: e.target.value }))}
                className="w-full h-10 bg-cc-base-elevated border border-cc-gridline rounded px-3 font-sans text-[13px] text-cc-text-high focus:border-cc-warm-primary focus:outline-none transition-colors"
              />
            </div>
          </div>

          {/* Organization */}
          <div className="mb-8">
            <h3 className="section-header mb-3">ORGANIZATION</h3>
            <div className="space-y-3">
              <div>
                <label className="font-mono text-[10px] font-medium uppercase tracking-[0.06em] text-cc-text-mid block mb-1.5">
                  Organization Name
                </label>
                <input
                  type="text"
                  value={formSettings.orgName}
                  onChange={(e) => setFormSettings((s) => ({ ...s, orgName: e.target.value }))}
                  className="w-full h-10 bg-cc-base-elevated border border-cc-gridline rounded px-3 font-sans text-[13px] text-cc-text-high focus:border-cc-warm-primary focus:outline-none transition-colors"
                />
              </div>
            </div>
          </div>

          {/* Dropdown Options */}
          <div className="mb-8">
            <h3 className="section-header mb-3">DROPDOWN OPTIONS</h3>

            <div className="mb-4">
              <label className="font-mono text-[10px] font-medium uppercase tracking-[0.06em] text-cc-text-mid block mb-2">
                Courses
              </label>
              <div className="flex flex-wrap gap-2">
                {formSettings.courses.map((course, i) => (
                  <span
                    key={course}
                    className="inline-flex items-center gap-1 bg-[rgba(91,168,124,0.08)] border border-[rgba(91,168,124,0.15)] rounded-sm px-2 py-0.5"
                  >
                    <span className="font-mono text-[10px] text-cc-warm-text">{course}</span>
                    <button onClick={() => removeCourse(i)} className="hover:text-cc-danger transition-colors">
                      <X size={10} className="text-cc-text-low" />
                    </button>
                  </span>
                ))}
              </div>
            </div>

            <div>
              <label className="font-mono text-[10px] font-medium uppercase tracking-[0.06em] text-cc-text-mid block mb-2">
                Branches
              </label>
              <div className="flex flex-wrap gap-2">
                {formSettings.branches.map((branch, i) => (
                  <span
                    key={branch}
                    className="inline-flex items-center gap-1 bg-[rgba(91,143,191,0.08)] border border-[rgba(91,143,191,0.15)] rounded-sm px-2 py-0.5"
                  >
                    <span className="font-mono text-[10px] text-cc-warm-text">{branch}</span>
                    <button onClick={() => removeBranch(i)} className="hover:text-cc-danger transition-colors">
                      <X size={10} className="text-cc-text-low" />
                    </button>
                  </span>
                ))}
              </div>
            </div>
          </div>

          {/* Notifications */}
          <div>
            <h3 className="section-header mb-3">NOTIFICATIONS</h3>
            <div className="space-y-3">
              <ToggleSwitch
                label="Email notifications for new registrations"
                checked={formSettings.emailNotifications}
                onChange={(v) => setFormSettings((s) => ({ ...s, emailNotifications: v }))}
              />
              <ToggleSwitch
                label="BGV status change alerts"
                checked={formSettings.bgvAlerts}
                onChange={(v) => setFormSettings((s) => ({ ...s, bgvAlerts: v }))}
              />
            </div>
          </div>
        </motion.div>

        {/* Save Button */}
        <div className="mt-6">
          <motion.button
            onClick={handleSave}
            disabled={!hasChanges || isSaving}
            whileTap={{ scale: 0.98 }}
            className={`px-8 py-3 font-mono text-xs font-semibold uppercase tracking-wider rounded transition-all ${
              saved
                ? 'bg-cc-green text-white'
                : 'bg-cc-warm-primary text-white hover:bg-cc-warm-primary-hover disabled:opacity-50 disabled:cursor-not-allowed'
            }`}
          >
            {isSaving ? 'SAVING...' : saved ? 'SAVED' : 'SAVE CHANGES'}
          </motion.button>
        </div>
      </div>
    </div>
  );
}

function ToggleSwitch({ label, checked, onChange }: { label: string; checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <button
      onClick={() => onChange(!checked)}
      className="flex items-center gap-3 w-full text-left"
    >
      <motion.div
        className="w-10 h-[22px] rounded-full relative flex-shrink-0"
        animate={{ backgroundColor: checked ? '#5BA87C' : '#2A3038' }}
        transition={{ duration: 0.2 }}
      >
        <motion.div
          className="w-[18px] h-[18px] rounded-full bg-white absolute top-[2px]"
          animate={{ left: checked ? 20 : 2 }}
          transition={{ duration: 0.2, ease: [0.4, 0, 0.2, 1] }}
        />
      </motion.div>
      <span className="font-sans text-[13px] text-cc-text-high">{label}</span>
    </button>
  );
}
